from mailchimp_marketing import Client

mailchimp = Client()
mailchimp.set_config({
  "api_key": "87d8291cb21765b69cd2bacb9b06d3a7-us2",
  "server": "us2"
})

response = mailchimp.ping.get()
print(response)

import mailchimp_marketing as MailchimpMarketing
from mailchimp_marketing.api_client import ApiClientError

try:
  client = MailchimpMarketing.Client()
  client.set_config({
    "api_key": "YOUR_API_KEY",
    "server": "YOUR_SERVER_PREFIX"
  })
  response = client.ping.get()
  print(response)
except ApiClientError as error:
  print(error)