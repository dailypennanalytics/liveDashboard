import facebook
from datetime import datetime
import pandas as pd
from requests import post

page_token = "EAAfue4ZCyTo4BAH1yjF5oV8yvgmumAW83HNH6fZC0b5mWbTQDpwNJlUOh4Iq67Ya2YQYibks4mdoUKfNfBuLKtmpG3vVi02rZCEJvMV5zURaQTYn0SbyJG9ABqN87dFEy0UkzvRFT3LUndlAzauNJNtnSE5mOBf8JDpnZAY5kJs1dutQ2hbiGTZCQmasjT5cq7NMfcNrzZCQZDZD"
graph = facebook.GraphAPI(access_token=page_token, version="3.1")

dp_page_id = 6356558804
dp_object = graph.get_object(id=dp_page_id)

print(dp_object)

dp_page_impressions = graph.get_connections(id=dp_page_id,
                                         connection_name='insights',
                                         metric='page_impressions',
                                         date_preset='yesterday',
                                         period='week',
                                         show_description_from_api_doc=True)


posts_2022 = graph.get_all_connections(id=dp_page_id,
                                       connection_name='posts',
                                       fields='type, name, created_time, object_id',
                                       since=datetime(2022, 1, 1))

recent_2_posts = graph.get_object(id=dp_page_id,
                                 fields='posts.attachments(type, name, object_id)')

post_1 = recent_2_posts['posts']['data'][0]
post_2 = recent_2_posts['posts']['data'][1]
print(post_1)
print(post_2)

post_1_activity_insights = graph.get_connections(id=post_1['id'],
                                                 connection_name='insights',
                                                 metric='post_impressions',
                                                 date_preset='yesterday',
                                                 period='lifetime',
                                                 show_description_from_api_doc=True)

post_2_activity_insights = graph.get_connections(id=post_2['id'],
                                                 connection_name='insights',
                                                 metric='post_impressions',
                                                 date_preset='yesterday',
                                                 period='lifetime',
                                                 show_description_from_api_doc=True)

print(post_1_activity_insights)
print(post_2_activity_insights)

# puts all the 2022 posts in a list, sorted by recency
posts_2022_list = [post for post in posts_2022]
post_impressions_unique = []
like_count = []
link_click_metric = []


for i in posts_2022_list:
    post_impressions_unique.append(graph.get_connections(id=posts_2022_list[i]['id'],
                                                 connection_name='insights',
                                                 metric='post_impressions_unique',
                                                 date_preset='yesterday',
                                                 period='lifetime',
                                                 show_description_from_api_doc=True))
    like_count.append(graph.get_connections(id=posts_2022_list[i]['id'],
                                                 connection_name='insights',
                                                 metric='post_reactions_like_total',
                                                 date_preset='yesterday',
                                                 period='lifetime',
                                                 show_description_from_api_doc=True))
    link_click_metric.append(graph.get_connections(id=posts_2022_list[i]['id'],
                                            connection_name='insights',
                                            metric='post_clicks_unique',
                                            date_preset='yesterday',
                                            period='lifetime',
                                            show_description_from_api_doc=True))


# table for top posts of the week (10)
# like count, impressions, link click metric
# filter it by link click
data = {'Posts': posts_2022_list, 'Posts Impressions': post_impressions_unique, 'Like Count': like_count,
        'Clicks': link_click_metric}
df = pd.DataFrame(data)
df.sort_values(
    by="link_click_metric",
    ascending=False
)

print(df)




